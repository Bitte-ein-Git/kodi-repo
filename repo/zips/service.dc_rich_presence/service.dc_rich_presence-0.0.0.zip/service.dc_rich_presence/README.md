# Kodi Addon - Discord Rich Presence (Token Auth)

This addon will display your current Kodi playback as Discord Rich Presence.