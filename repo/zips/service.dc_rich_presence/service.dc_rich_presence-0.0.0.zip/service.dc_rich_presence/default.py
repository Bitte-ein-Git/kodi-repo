import xbmc
import xbmcaddon
import xbmcgui
import time
import requests
import json
import re
import xbmcvfs
import base64
import urllib.parse
from resources.lib.discord_gateway import DiscordClient, DiscordConnectionError

ADDON = xbmcaddon.Addon()
IMAGE_CACHE = {} # simple in-memory cache for imgbb urls
TRANSLATIONS = {}

# --- Helper Functions ---

def rpc_call(method, params=None):
    # send json-rpc request to kodi
    try:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params:
            payload["params"] = params
        response_str = xbmc.executeJSONRPC(json.dumps(payload))
        response_data = json.loads(response_str)
        if 'result' in response_data:
            return response_data
        elif 'error' in response_data:
            xbmc.log(f"[DiscordRPC] JSON-RPC Error: {response_data['error']}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"[DiscordRPC] Error in rpc_call ({method}): {e}", xbmc.LOGERROR)
    return None

def get_kodi_image_base64(image_path):
    if not image_path:
        return None
    try:
        # Resolve Kodi's "image://" URLs
        if image_path.startswith("image://"):
            decoded_path = urllib.parse.unquote(image_path[8:])
            if decoded_path.endswith('/'):
                decoded_path = decoded_path[:-1]
        else:
            decoded_path = image_path

        # Translate Kodi's virtual path to a real file system path
        resolved_path = xbmcvfs.translatePath(decoded_path)

        # Open file in binary mode
        f = xbmcvfs.File(resolved_path, 'rb')
        data = f.read()
        f.close()

        # check if return a str instead of bytes
        if isinstance(data, str):
            data = data.encode('utf-8')

        # Convert the image data to base64 string
        return base64.b64encode(data).decode('utf-8')

    except Exception as e:
        xbmc.log(f"[DiscordRPC] Could not convert image to base64: {e}", xbmc.LOGWARNING)
        return None

def upload_to_imgbb(api_key, image_base64):
    # upload base64 image string to imgbb
    if not api_key or not image_base64:
        return None
    
    url = "https://api.imgbb.com/1/upload"
    payload = {
        "key": api_key,
        "image": image_base64,
        "expiration": 21600 # 6 hours
    }
    try:
        response = requests.post(url, data=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data and data.get("success"):
            image_url = data.get("data", {}).get("url")
            if image_url:
                xbmc.log(f"[DiscordRPC] ImgBB upload successful: {image_url}", xbmc.LOGINFO)
                return image_url
            
        xbmc.log(f"[DiscordRPC] ImgBB upload failed, response: {data}", xbmc.LOGERROR)
        return None
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[DiscordRPC] Error uploading to ImgBB: {e}", xbmc.LOGERROR)
        return None

def get_and_process_image_url(api_key, kodi_image_path, fallback_image_key):
    # main image handler
    if not kodi_image_path:
        return fallback_image_key

    # return from cache if available
    if kodi_image_path in IMAGE_CACHE:
        return IMAGE_CACHE[kodi_image_path]

    # if it's already a web url, just use it
    if kodi_image_path.startswith("http://") or kodi_image_path.startswith("https://"):
        return kodi_image_path

    # if it's a kodi vfs path, upload it
    if kodi_image_path.startswith("image://"):
        base64_data = get_kodi_image_base64(kodi_image_path)
        if base64_data:
            imgbb_url = upload_to_imgbb(api_key, base64_data)
            if imgbb_url:
                IMAGE_CACHE[kodi_image_path] = imgbb_url # cache success
                return imgbb_url

    # fallback to default
    return fallback_image_key

def load_translations():
    global TRANSLATIONS
    try:
        en_json = {
          "state": {
            "no_playback": "No Playback",
            "no_audio_info": "No Audio Info",
            "kodi_offline": "Kodi offline",
            "stereo": "Stereo",
            "channel_5_1": "5.1-Channel",
            "channel_7_1": "7.1-Channel",
            "channel_multi": "{channels}-Channel",
            "movie": "🎬 Movie",
            "tv_show": "🎞️ TV Show"
          }
        }
        TRANSLATIONS = en_json.get("state", {})
        xbmc.log("[DiscordRPC] Loaded built-in translations.", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[DiscordRPC] Could not load translations: {e}", xbmc.LOGERROR)
        TRANSLATIONS = {}

def get_translation(key, placeholders=None):
    # get translation string
    if placeholders is None:
        placeholders = {}
    return TRANSLATIONS.get(key, key).format(**placeholders)

def get_playing_addon(is_pvr, item):
    # get playing addon name
    try:
        file_path = item.get('file', "")
        if not file_path:
            return ""

        if is_pvr:
            art = item.get('art', {})
            for art_type in art:
                url = art[art_type].lower()
                if 'pluto.tv' in url:
                    return "Pluto.TV"
                elif 't-online' in url or 'telekom' in url:
                    return "MagentaTV"
            return "IPTV"

        if file_path.startswith('plugin://'):
            addon_id = file_path.split('/')[2]
            try:
                addon_obj = xbmcaddon.Addon(addon_id)
                addon_name = addon_obj.getAddonInfo('name')
                return addon_name
            except RuntimeError:
                return addon_id

        studios = [s.lower() for s in item.get('studio', [])]
        if any(s in ['disney', 'pixar'] for s in studios): return "Disney+"
        if any(s in ['paramount', 'viacom', 'nickelodeon'] for s in studios): return "Paramount+"
        
        if 'amazon-test' in file_path: return "Prime Video"
        if 'dmax' in file_path: return "DMAX Mediathek"
        if 'discoveryplus' in file_path: return "Discovery+"
        if 'joyn' in file_path: return "Joyn"
        if 'rtlgroup' in file_path or 'rtlplus' in file_path: return "RTL+"
        if 'jellyfin' in file_path: return "Jellyfin"
            
    except Exception as e:
        xbmc.log(f"[DiscordRPC] Could not get playing addon name: {e}", xbmc.LOGWARNING)
    return ""

def time_obj_to_seconds(time_dict):
    # convert time object to seconds
    if not isinstance(time_dict, dict): return 0
    return (time_dict.get('hours', 0) * 3600 +
            time_dict.get('minutes', 0) * 60 +
            time_dict.get('seconds', 0) +
            time_dict.get('milliseconds', 0) / 1000.0)

def show_notification(title, message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    # display a notification in kodi
    xbmcgui.Dialog().notification(title, message, icon, duration)

# --- Main Service Class ---

class DiscordRichPresenceService(xbmc.Monitor):
    def __init__(self):
        super(DiscordRichPresenceService, self).__init__()
        self.client = None
        self.settings_changed = False
        load_translations()
        self.load_settings()

    def load_settings(self):
        # load addon settings
        self.app_id = ADDON.getSettingString("app_id")
        self.user_token = ADDON.getSettingString("user_token")
        self.imgbb_api_key = ADDON.getSettingString("imgbb_api_key")
        self.display_addon_name = ADDON.getSettingBool("display_addon_name")
        self.media_display_mode = ADDON.getSettingString("media_display_mode")
        self.pvr_display_mode = ADDON.getSettingString("pvr_display_mode")
        self.icon_color = ADDON.getSettingString("icon_color")
        xbmc.log("[DiscordRPC] Settings loaded.", xbmc.LOGINFO)

    def onSettingsChanged(self):
        # handle settings changes
        xbmc.log("[DiscordRPC] Settings changed. Triggering restart.", xbmc.LOGINFO)
        self.settings_changed = True

    def is_config_valid(self):
        # validate configuration
        if not all([self.app_id, self.user_token]):
            show_notification("Discord Presence", "Discord App ID or User Token missing!", xbmcgui.NOTIFICATION_ERROR)
            return False
        if not self.imgbb_api_key:
            show_notification("Discord Presence", "ImgBB API Key is missing! Artwork will not be shown.", xbmcgui.NOTIFICATION_WARNING)
            # allow running without imgbb, but warn user
        return True

    def run_service(self):
        # main service loop
        if not self.is_config_valid():
            xbmc.log("[DiscordRPC] Configuration is incomplete. Halting addon.", xbmc.LOGERROR)
            return

        try:
            xbmc.log("[DiscordRPC] Starting Discord client...", xbmc.LOGINFO)
            self.client = DiscordClient(self.app_id, self.user_token)
            self.client.connect()
            time.sleep(5)
            xbmc.log("[DiscordRPC] Service initialized.", xbmc.LOGINFO)
        except DiscordConnectionError as e:
            xbmc.log(f"[DiscordRPC] Initial connection failed: {e}", xbmc.LOGERROR)
            show_notification("Discord Presence", "Connection failed. Check token.", xbmcgui.NOTIFICATION_ERROR)
            return

        last_payload_str = ""

        while not self.abortRequested() and not self.settings_changed:
            try:
                if not self.client or not self.client.connected:
                    xbmc.log("[DiscordRPC] Not connected. Attempting to reconnect...", xbmc.LOGWARNING)
                    show_notification("Discord Presence", "Connection lost. Reconnecting...")
                    self.client.reconnect()
                    time.sleep(5)
                    if not self.client.connected:
                        if self.waitForAbort(15): break
                        continue
                
                # check kodi connection
                if not rpc_call("JSONRPC.Ping"):
                    offline_state = get_translation('kodi_offline')
                    payload = self.build_payload(False, offline_state, offline_state, False, "", None, None)
                    if str(payload) != last_payload_str:
                        self.client.set_activity(payload)
                        last_payload_str = str(payload)
                    if self.waitForAbort(15): break
                    continue

                is_playing = xbmc.Player().isPlaying()
                is_paused = xbmc.getCondVisibility('Player.Paused')
                is_pvr = xbmc.getCondVisibility("Pvr.IsPlayingTv")

                mode = self.pvr_display_mode if is_pvr else self.media_display_mode
                if not is_playing or mode == "disabled":
                    if last_payload_str:
                        xbmc.log("[DiscordRPC] Clearing presence (stopped).", xbmc.LOGINFO)
                        self.client.clear_activity()
                        last_payload_str = ""
                    if self.waitForAbort(5): break
                    continue
                
                # get player id
                players = rpc_call("Player.GetActivePlayers")
                no_playback_state = get_translation('no_playback') # define here for safety
                
                if not players or not players.get('result'):
                    # no active player -> Presence cleared
                    if last_payload_str:
                        xbmc.log("[DiscordRPC] Clearing presence (no active player).", xbmc.LOGINFO)
                        self.client.clear_activity()
                        last_payload_str = ""
                    if self.waitForAbort(5): 
                        break
                    continue

                else:
                    playerid = players['result'][0]['playerid']
                    
                    # get playback data
                    item_data = rpc_call("Player.GetItem", {"playerid": playerid, "properties": ["title", "showtitle", "season", "episode", "year", "tvshowid", "file", "streamdetails", "art", "channel", "channeltype", "studio"]})
                    audio_data = rpc_call("Player.GetProperties", {"playerid": playerid, "properties": ["audiostreams", "currentaudiostream"]})
                    
                    # --- Ported kodi_helpers logic ---
                    media_type, main_info, extra_info, audio_info = 'Other', '', '', ''

                    if item_data and 'result' in item_data:
                        item = item_data['result']['item']
                        
                        if not item.get('title') and item.get('label'):
                            # label parsing for tv shows
                            label = item.get('label')
                            match = re.match(r'^(.*)\sS(\d{1,2})E(\d{1,2})', label, re.IGNORECASE)
                            if match:
                                media_type = get_translation('tv_show')
                                main_info = match.group(1).strip()
                                extra_info = f"S{int(match.group(2)):02d}E{int(match.group(3)):02d}"

                        if not main_info:
                            # default processing for media types
                            if item.get('channeltype') == 'tv' or item.get('channel'):
                                media_type = 'Live TV'
                                main_info = (item.get('channel') or '📺 Live TV') + ' ᴵᴾᵀⱽ'
                                extra_info = item.get('title') or '🎬 Live TV'
                            elif item.get('type') == 'movie':
                                media_type = get_translation('movie')
                                main_info = f"{item.get('title','')} ({item.get('year','')})".strip()
                                extra_info = '🎬 Film'
                            elif item.get('type') == 'episode' or item.get('tvshowid'):
                                if item.get('season') == -1 and item.get('episode') == -1:
                                    media_type = get_translation('movie')
                                    main_info = item.get('label')
                                    extra_info = get_translation('movie')
                                else:
                                    media_type = get_translation('tv_show')
                                    main_info = f"{item.get('showtitle','')} ({item.get('year','')})".strip()
                                    extra_info = f"S{int(item['season']):02d}E{int(item['episode']):02d} » {item.get('title','')}" if item.get('season') is not None and item.get('episode') is not None else '🎞️ Serie'
                            else:
                                media_type, main_info, extra_info = 'Other', item.get('label') or no_playback_state, 'Other'

                        # cleanup extra info
                        if 'S-1E-1' in extra_info:
                            extra_info = ''

                        # cleanup main info
                        no_tags = re.sub(r'\[.*?\]', '', main_info)
                        no_zero = re.sub(r'\s*\(0\)', '', no_tags)
                        main_info = no_zero.strip()

                    if audio_data and 'result' in audio_data and audio_data['result'].get('audiostreams'):
                        # audio info processing
                        streams = audio_data['result'].get('audiostreams', [])
                        current = audio_data['result'].get('currentaudiostream', {}).get('index')
                        no_audio_state = get_translation('no_audio_info')
                        if current is not None and current < len(streams):
                            stream = streams[current]
                            codec = stream.get('codec','').lower()
                            channels = stream.get('channels', 0)
                            channel_str_map = {
                                2: get_translation('stereo'),
                                6: get_translation('channel_5_1'),
                                8: get_translation('channel_7_1')
                            }
                            channel_str = channel_str_map.get(channels, get_translation('channel_multi', {"channels": str(channels)}))

                            codec_map = {
                                'ac3': 'Dolby Digital', 'eac3': 'Dolby Digital+', 'dts': 'DTS', 'aac': 'AAC',
                                'dca': 'DTS', 'dolbydigital': 'Dolby Digital', 'dtshd_hra': 'DTS-HD HRA',
                                'dtshd_ma': 'DTS-HD MA', 'dtshd_ma_x': 'DTS-HD MA X', 'dtshd_ma_x_ima': 'DTS-HD MA X (IMAX)',
                                'dtsma': 'DTS Master Audio', 'eac3_ddp_atmos': 'Dolby Atmos (DD+)',
                                'truehd': 'Dolby TrueHD', 'truehd_atmos': 'Dolby Atmos+TrueHD'
                            }

                            if codec.startswith('pcm'):
                                codec_str = 'PCM'
                            else:
                                codec_str = codec_map.get(codec, codec.upper())
                            audio_info = f"{codec_str} | {channel_str}"
                        else:
                            audio_info = no_audio_state
                    else:
                        audio_info = get_translation('no_audio_info')
                    
                    # --- End of ported logic ---
                    
                    details_val = main_info or no_playback_state
                    state_val = extra_info or ' ' # discord state needs at least one char
                    
                    addon_name = get_playing_addon(is_pvr, item_data.get('result', {}).get('item', {}))
                    
                    payload = self.build_payload(is_pvr, details_val, state_val, is_paused, addon_name, item_data, audio_info)

                if not payload:
                    if self.waitForAbort(5): break
                    continue
                
                current_payload_str = str(payload)
                if current_payload_str != last_payload_str:
                    xbmc.log(f"[DiscordRPC] Updating presence: {payload.get('details')} | Paused: {is_paused}", xbmc.LOGINFO)
                    self.client.set_activity(payload)
                    last_payload_str = current_payload_str

                if self.waitForAbort(5): break
            
            except DiscordConnectionError as e:
                xbmc.log(f"[DiscordRPC] Connection error in main loop: {e}", xbmc.LOGERROR)
                last_payload_str = "" # force update on reconnect
                if self.waitForAbort(15): break
            
            except Exception as e:
                xbmc.log(f"[DiscordRPC] Unhandled error in loop: {e}", xbmc.LOGERROR)
                show_notification("Discord Presence", "An error occurred. Restarting...", xbmcgui.NOTIFICATION_ERROR)
                if self.waitForAbort(30): break
        
        if self.client:
            xbmc.log("[DiscordRPC] Stopping service or restarting.", xbmc.LOGINFO)
            self.client.disconnect()
        
        if self.settings_changed:
            self.settings_changed = False

    def build_payload(self, is_pvr, details_val, state_val, is_paused, addon_name, item_data, audio_info):
        # build discord payload
        payload = { "name": "Kodi", "type": 3, "application_id": self.app_id }
        
        # add addon name to state if enabled
        if self.display_addon_name and addon_name and not is_paused:
            state_val = f"{state_val} • {addon_name}" if state_val.strip() else addon_name

        mode_map = {
            (False, "App name"):    (details_val, state_val, 0),
            (False, "Media title"): (details_val, state_val, 2),
            (True, "App name"):      (details_val, state_val, 0),
            (True, "Channel name"):  (details_val, state_val, 2),
            (True, "TV-show title"): (state_val, details_val, 2)
        }
        
        mode_label = self.pvr_display_mode if is_pvr else self.media_display_mode
        config = mode_map.get((is_pvr, mode_label))

        if not config: 
            return None

        payload["details"] = config[0]
        payload["state"] = config[1]
        payload["status_display_type"] = config[2]

        if addon_name == "Pluto.TV":
            payload["state"] = "Livestream - Pluto.TV"

        # get timestamps
        player_props = rpc_call("Player.GetProperties", {"playerid": 1, "properties": ["time", "totaltime"]})
        if player_props and 'result' in player_props:
            try:
                time_data = player_props['result']
                current_time_sec = time_obj_to_seconds(time_data.get('time'))
                total_time_sec = time_obj_to_seconds(time_data.get('totaltime'))

                if total_time_sec > 0 and not is_paused:
                    now_ts = time.time()
                    start_ts = now_ts - current_time_sec
                    end_ts = start_ts + total_time_sec
                    payload["timestamps"] = {
                        "start": int(start_ts * 1000),
                        "end": int(end_ts * 1000)
                    }
            except Exception as e:
                xbmc.log(f"[DiscordRPC] Failed to set timestamps: {e}", xbmc.LOGWARNING)

        # --- Asset (Image) Logic ---
        assets = {}
        kodi_image_path = ""
        item_art = item_data.get('result', {}).get('item', {}).get('art', {}) if item_data else {}
        
        # set fallback keys
        fallback_large_key = "1405130772981223454" # kodi logo
        small_image_key = "1407207958294564884" if self.icon_color == 'Greyscale' else "1407207956914634772" # movie icon
        small_text = audio_info if audio_info and audio_info != get_translation('no_audio_info') else "Media"

        if is_pvr:
            kodi_image_path = item_art.get('thumb') # channel logo
            small_image_key = "1407207956877021236" if self.icon_color == 'Greyscale' else "1407207958252884149" # pvr icon
            small_text = "Live TV"
        else:
            # try to get thumb, poster, or fanart
            kodi_image_path = item_art.get('poster') or item_art.get('fanart')
        
        # get image url (either from cache, new upload, or fallback)
        large_image_key = get_and_process_image_url(self.imgbb_api_key, kodi_image_path, fallback_large_key)
        
        assets["large_image"] = large_image_key
        assets["large_text"] = details_val if not is_pvr else state_val
        assets["small_image"] = small_image_key
        assets["small_text"] = small_text
        
        # override for pause
        if is_paused:
            pause_image_key = "1407207956851982336" if self.icon_color == 'Greyscale' else "1407207957422411849"
            assets["small_image"] = pause_image_key
            assets["small_text"] = "PAUSE ⏸️"
            payload["state"] = "PAUSE ⏸️"
            if "timestamps" in payload:
                del payload["timestamps"]
        
        payload["assets"] = assets
        return payload

# --- Main Execution ---

if __name__ == "__main__":
    xbmc.log("[DiscordRPC] Addon starting.", xbmc.LOGINFO)
    service = DiscordRichPresenceService()
    
    while not xbmc.Monitor().abortRequested():
        try:
            service.load_settings()
            service.run_service()
        except Exception as e:
            xbmc.log(f"[DiscordRPC] Unhandled exception, restarting in 30s: {e}", xbmc.LOGERROR)
            show_notification("Discord Presence", "Addon crashed! Restarting...", xbmcgui.NOTIFICATION_ERROR)
            if xbmc.Monitor().waitForAbort(30):
                break
        
        if service.settings_changed:
            xbmc.log("[DiscordRPC] Restarting due to settings change.", xbmc.LOGINFO)
        elif not xbmc.Monitor().abortRequested():
            if xbmc.Monitor().waitForAbort(2):
                break

    xbmc.log("[DiscordRPC] Addon has been shut down.", xbmc.LOGINFO)