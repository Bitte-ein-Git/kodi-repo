import xbmc
import xbmcaddon
import xbmcgui
import json
import time
import urllib.parse
from resources.lib.discord_gateway import DiscordClient, DiscordConnectionError

ADDON = xbmcaddon.Addon()

def show_notification(title, message, icon=xbmcgui.NOTIFICATION_INFO, duration=4000):
    # display notification
    xbmcgui.Dialog().notification(title, message, icon, duration)

def decode_kodi_image_url(image_url):
    # decode kodi image url
    if not image_url:
        return None
    try:
        if image_url.startswith("image://"):
            clean_url = image_url[len("image://"):]
            if clean_url.endswith("/"):
                clean_url = clean_url[:-1]
            return urllib.parse.unquote(clean_url)
        return image_url
    except Exception as e:
        xbmc.log(f"[DiscordRPC] Image decode failed: {e}", xbmc.LOGWARNING)
        return None

class DiscordKodiService(xbmc.Monitor):
    def __init__(self):
        super(DiscordKodiService, self).__init__()
        self.client = None
        self.last_payload_str = ""
        self.load_settings()

    def load_settings(self):
        # load addon settings
        self.app_id = ADDON.getSettingString("app_id")
        self.user_token = ADDON.getSettingString("user_token")
        self.icon_color = ADDON.getSettingString("icon_color")
        xbmc.log("[DiscordRPC] Settings loaded.", xbmc.LOGINFO)

    def is_config_valid(self):
        # check required settings
        return all([self.app_id, self.user_token])

    def get_current_playing_info(self):
        # get player item details via jsonrpc
        try:
            rpc_query = json.dumps({
                "jsonrpc": "2.0",
                "method": "Player.GetItem",
                "params": {"playerid": 1, "properties": ["title", "showtitle", "season", "episode", "album", "artist", "genre", "streamdetails", "art", "duration", "channel", "year", "uniqueid"]},
                "id": 1
            })
            rpc_response = xbmc.executeJSONRPC(rpc_query)
            data = json.loads(rpc_response)
            return data.get("result", {}).get("item", {})
        except Exception as e:
            xbmc.log(f"[DiscordRPC] Error fetching playback info: {e}", xbmc.LOGERROR)
            return {}

    def get_playback_time(self):
        # get player time properties via jsonrpc
        try:
            rpc_query = json.dumps({
                "jsonrpc": "2.0",
                "method": "Player.GetProperties",
                "params": {"playerid": 1, "properties": ["time", "totaltime"]},
                "id": 1
            })
            rpc_response = xbmc.executeJSONRPC(rpc_query)
            data = json.loads(rpc_response)
            props = data.get("result", {})
            current = self.time_to_seconds(props.get("time", {}))
            total = self.time_to_seconds(props.get("totaltime", {}))
            return current, total
        except Exception as e:
            xbmc.log(f"[DiscordRPC] Error fetching playback time: {e}", xbmc.LOGERROR)
            return 0, 0

    def time_to_seconds(self, time_dict):
        # convert kodi time object to seconds
        if not time_dict:
            return 0
        return (time_dict.get("hours", 0) * 3600 +
                time_dict.get("minutes", 0) * 60 +
                time_dict.get("seconds", 0) +
                time_dict.get("milliseconds", 0) / 1000.0)

    def build_payload(self, info, is_pvr, is_paused, current_time, total_time):
        # build the discord activity payload
        title = info.get("title") or info.get("label") or "Unbekannter Titel"
        year = info.get("year", 0) or 0
        details = f"{title} ({year})" if year > 0 else title
        
        state = ""
        assets = {}
        art = info.get("art", {})
        art_url = None
        
        # select assets based on icon color setting
        if self.icon_color == 'Greyscale':
            large_image_key = "1405130772981223454"
            small_image_key_pvr = "1407207956877021236"
            small_image_key_media = "1407207958294564884"
            pause_image_key = "1407207956851982336"
        else: # colored
            large_image_key = "1405130772981223454"
            small_image_key_pvr = "1407207958252884149"
            small_image_key_media = "1407207956914634772"
            pause_image_key = "1407207957422411849"
            
        small_image_key = small_image_key_pvr
        small_text = "Live TV"

        if is_pvr:
            channel_name = info.get("channel", "")
            season = info.get("season", 0) or 0
            episode = info.get("episode", 0) or 0
            
            if season > 0 and episode > 0:
                state = f"🎞️ S{season:02d}E{episode:02d} • {channel_name}"
            else:
                state = channel_name
                
            art_url = art.get("thumb")
        else:
            art_url = art.get("poster") or art.get("tvshow.poster") or art.get("thumb")
            
            showtitle = info.get("showtitle")
            season = info.get("season", 0) or 0
            episode = info.get("episode", 0) or 0
            
            if showtitle and season > 0 and episode > 0:
                # series
                state = f"🎞️ » S{season:02d}E{episode:02d}"
            else:
                # movie or addon
                genres = info.get("genre", [])
                if genres:
                    state = "🎭 » " + ", ".join(genres)
                else:
                    state = "🎬 Movie"
            
            small_image_key = small_image_key_media
            small_text = "Playing"

        # dynamic artwork processing
        if art_url:
            decoded_url = decode_kodi_image_url(art_url)
            
            if decoded_url and (decoded_url.startswith("http://") or decoded_url.startswith("https://")):
                # remote url (http/https), pass to discord gateway
                large_image_key = decoded_url
                xbmc.log(f"[DiscordRPC] Using decoded remote URL: {decoded_url}", xbmc.LOGINFO)

        # handle pause state
        if is_paused:
            small_image_key = pause_image_key
            small_text = "PAUSE ⏸️"
            
        # timestamps for playback progress
        timestamps = {}
        if not is_paused and total_time > 0:
            now = time.time()
            start_timestamp = now - current_time
            end_timestamp = start_timestamp + total_time
            timestamps = {"start": int(start_timestamp * 1000), "end": int(end_timestamp * 1000)}

        assets["large_image"] = large_image_key
        assets["large_text"] = details
        assets["small_image"] = small_image_key
        assets["small_text"] = small_text

        payload = {
            "name": "Kodi",
            "type": 3,
            "application_id": self.app_id,
            "details": details,
            "state": state,
            "status_display_type": 2,
            "assets": assets,
        }

        if timestamps:
            payload["timestamps"] = timestamps

        return payload

    def run_service(self):
        # main service loop
        if not self.is_config_valid():
            xbmc.log("[DiscordRPC] Incomplete configuration.", xbmc.LOGERROR)
            show_notification("Discord Presence", "Configuration incomplete!", xbmcgui.NOTIFICATION_ERROR)
            return

        try:
            self.client = DiscordClient(self.app_id, self.user_token)
            self.client.connect()
            xbmc.log("[DiscordRPC] Discord client connected.", xbmc.LOGINFO)
        except DiscordConnectionError as e:
            xbmc.log(f"[DiscordRPC] Connection failed: {e}", xbmc.LOGERROR)
            show_notification("Discord Presence", "Connection failed to Discord.", xbmcgui.NOTIFICATION_ERROR)
            return

        while not self.abortRequested():
            try:
                if not self.client.connected.is_set():
                    xbmc.log("[DiscordRPC] Not connected. Attempting reconnect.", xbmc.LOGWARNING)
                    try:
                        self.client.reconnect()
                    except DiscordConnectionError:
                        xbmc.log("[DiscordRPC] Reconnect failed. Retrying later.", xbmc.LOGERROR)
                    if self.waitForAbort(15): break
                    continue

                player = xbmc.Player()
                is_playing = player.isPlaying()
                is_paused = xbmc.getCondVisibility("Player.Paused")
                is_pvr = xbmc.getCondVisibility("Pvr.IsPlayingTv")

                if not is_playing:
                    if self.last_payload_str:
                        xbmc.log("[DiscordRPC] Stopped, clearing presence.", xbmc.LOGINFO)
                        self.client.clear_activity()
                        self.last_payload_str = ""
                    if self.waitForAbort(5): break
                    continue

                info = self.get_current_playing_info()
                current_time, total_time = self.get_playback_time()
                payload = self.build_payload(info, is_pvr, is_paused, current_time, total_time)

                current_payload_str = str(payload)
                if current_payload_str != self.last_payload_str:
                    xbmc.log(f"[DiscordRPC] Updating activity: {payload.get('details')}", xbmc.LOGINFO)
                    self.client.set_activity(payload)
                    self.last_payload_str = current_payload_str

                if self.waitForAbort(10): break

            except DiscordConnectionError as e:
                 xbmc.log(f"[DiscordRPC] Connection error in loop: {e}", xbmc.LOGERROR)
                 self.last_payload_str = ""
                 if self.waitForAbort(15): break
            except Exception as e:
                xbmc.log(f"[DiscordRPC] Service error: {e}", xbmc.LOGERROR, exc_info=True)
                show_notification("Discord Presence", "Error in DiscordRPC loop.", xbmcgui.NOTIFICATION_ERROR)
                if self.waitForAbort(15): break

        if self.client:
            self.client.disconnect()
        xbmc.log("[DiscordRPC] Service stopped.", xbmc.LOGINFO)


if __name__ == "__main__":
    xbmc.log("[DiscordRPC] Starting standalone service.", xbmc.LOGINFO)
    service = DiscordKodiService()
    service.run_service()